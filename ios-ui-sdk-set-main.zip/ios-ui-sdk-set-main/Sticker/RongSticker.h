//
//  RongSticker.h
//  RongSticker
//
//  Created by Zhaoqianyu on 2018/8/7.
//  Copyright © 2018年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RongSticker.
FOUNDATION_EXPORT double RongStickerVersionNumber;

//! Project version string for RongSticker.
FOUNDATION_EXPORT const unsigned char RongStickerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import
// <RongSticker/PublicHeader.h>
