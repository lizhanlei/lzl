//
//  RCStickerPackageTabSource.h
//  RongSticker
//
//  Created by Zhaoqianyu on 2018/8/13.
//  Copyright © 2018年 RongCloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RongStickerAdaptiveHeader.h"

@interface RCStickerPackageTabSource : NSObject <RCEmoticonTabSource>

@property (nonatomic, strong) NSString *packageId;

@end
