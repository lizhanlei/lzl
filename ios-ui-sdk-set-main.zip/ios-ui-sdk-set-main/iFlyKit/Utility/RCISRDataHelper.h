//
//  RCISRDataHelper.h
//  RongiFlyKit
//
//  Created by ypzhao on 12-11-19.
//  Copyright (c) 2012年 iflytek. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RCISRDataHelper : NSObject
/**
 解析JSON数据
 ****/
+ (NSString *)stringFromJson:(NSString *)params; //

@end
