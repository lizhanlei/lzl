//
//  RCBaseTableViewController.h
//  RongIMKit
//
//  Created by Sin on 2020/6/2.
//  Copyright © 2020 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

/*!
IMKit UITableViewController 基类

*/

@interface RCBaseTableViewController : UITableViewController

@end
