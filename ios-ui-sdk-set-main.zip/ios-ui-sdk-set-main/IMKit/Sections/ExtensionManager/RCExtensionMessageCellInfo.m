//
//  RCExtensionMessageCellInfo.m
//  RongIMExtension
//
//  Created by 岑裕 on 2016/10/18.
//  Copyright © 2016年 RongCloud. All rights reserved.
//

#import "RCExtensionMessageCellInfo.h"

@implementation RCExtensionMessageCellInfo

@end
