//
//  RCCombineMessage.h
//  RongIMLib
//
//  Created by liyan on 2019/8/13.
//  Copyright © 2019 RongCloud. All rights reserved.
//

#import <RongIMLib/RongIMLib.h>

NS_ASSUME_NONNULL_BEGIN

/*!
 合并转发消息的类型名
 */
#define RCCombineMessageTypeIdentifier @"RC:CombineMsg"

@interface RCCombineMessage : RCMediaMessageContent

/*!
 转发的消息展示的缩略内容列表 (格式是发送者 ：缩略内容)
 */
@property (nonatomic, strong) NSArray *summaryList;

/*!
 转发的全部消息的发送者名称列表 （单聊是经过排重的，群聊是群组名称）
 */
@property (nonatomic, strong) NSArray *nameList;

/*!
 转发的消息会话类型 （目前仅支持单聊和群聊）
 */
@property (nonatomic, assign) RCConversationType conversationType;

/*!
 转发的消息 消息的附加信息
 */
@property (nonatomic, copy) NSString *extra;

/*!
 初始化 RCCombineMessage 消息

 @param summaryList         转发的消息展示的缩略内容列表
 @param nameList            转发的全部消息的发送者名称列表 （单聊是经过排重的，群聊是群组名称）
 @param conversationType    转发的消息会话类型
 @param content             转发的内容

 @return                    消息对象
 */
+ (instancetype)messageWithSummaryList:(NSArray *)summaryList
                              nameList:(NSArray *)nameList
                      conversationType:(RCConversationType)conversationType
                               content:(NSString *)content;

@end

NS_ASSUME_NONNULL_END
