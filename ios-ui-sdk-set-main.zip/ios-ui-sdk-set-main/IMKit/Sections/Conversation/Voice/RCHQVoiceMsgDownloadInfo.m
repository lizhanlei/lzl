//
//  RCHQVoiceMsgDownloadInfo.m
//  RongIMKit
//
//  Created by Zhaoqianyu on 2019/5/22.
//  Copyright © 2019 RongCloud. All rights reserved.
//

#import "RCHQVoiceMsgDownloadInfo.h"

@implementation RCHQVoiceMsgDownloadInfo

@end
