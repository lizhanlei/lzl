//
//  RCCustomerServiceGroupCell.h
//  RongIMKit
//
//  Created by 张改红 on 16/7/19.
//  Copyright © 2016年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCCustomerServiceGroupCell : UITableViewCell
@property (nonatomic, strong) UILabel *groupName;
@end
