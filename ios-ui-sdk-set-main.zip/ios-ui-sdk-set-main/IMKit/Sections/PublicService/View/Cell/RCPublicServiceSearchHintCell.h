//
//  RCPublicServiceSearchHintCell.h
//  RongIMKit
//
//  Created by litao on 15/4/21.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCPublicServiceSearchHintCell : UITableViewCell
- (void)setSearchKey:(NSString *)key;
@end
