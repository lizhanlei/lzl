//
//  RCPublicServiceProfilePlainCell.h
//  HelloIos
//
//  Created by litao on 15/4/10.
//  Copyright (c) 2015年 litao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCPublicServiceProfilePlainCell : UITableViewCell
- (void)setTitle:(NSString *)title Content:(NSString *)content;
@end
