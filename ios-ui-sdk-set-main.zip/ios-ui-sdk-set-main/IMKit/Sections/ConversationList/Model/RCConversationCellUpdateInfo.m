//
//  RCConversationCellUpdateNotification.m
//  RongIMKit
//
//  Created by 岑裕 on 16/9/11.
//  Copyright © 2016年 RongCloud. All rights reserved.
//

#import "RCConversationCellUpdateInfo.h"

NSString *const RCKitConversationCellUpdateNotification = @"RCKitConversationCellUpdateNotification";

@implementation RCConversationCellUpdateInfo

@end
