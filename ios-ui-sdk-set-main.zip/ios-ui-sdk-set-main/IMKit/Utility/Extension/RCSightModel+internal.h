//
//  RCSightModel+internal.h
//  RongIMKit
//
//  Created by 张改红 on 2021/5/10.
//  Copyright © 2021 RongCloud. All rights reserved.
//

#ifndef RCSightModel_internal_h
#define RCSightModel_internal_h
#import "RCSightPlayerController+imkit.h"
@interface RCSightModel()
@property (nonatomic, strong) RCSightPlayerController *playerController;
@end

#endif /* RCSightModel_internal_h */
