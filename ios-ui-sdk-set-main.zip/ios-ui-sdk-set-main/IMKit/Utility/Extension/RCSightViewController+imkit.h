//
//  RCSightViewController+imkit.h
//  RongIMKit
//
//  Created by 张改红 on 2020/12/23.
//  Copyright © 2020 RongCloud. All rights reserved.
//

#ifndef RCSightViewController_imkit_h
#define RCSightViewController_imkit_h

@interface RCSightViewController : UIViewController
@property (nonatomic, weak, nullable) id delegate;
@end

#endif /* RCSightViewController_imkit_h */
