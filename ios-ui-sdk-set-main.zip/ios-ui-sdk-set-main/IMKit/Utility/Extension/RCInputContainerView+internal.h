//
//  RCInputContainerView+internal.h
//  RongIMKit
//
//  Created by 张改红 on 2020/12/9.
//  Copyright © 2020 RongCloud. All rights reserved.
//

#ifndef RCInputContainerView_internal_h
#define RCInputContainerView_internal_h

@interface RCInputContainerView ()
@property (nonatomic, assign) BOOL textViewBeginEditing;
@end

#endif /* RCInputContainerView_internal_h */
