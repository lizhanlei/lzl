//
//  RCMJRefreshBackFooter.h
//  RCMJRefreshExample
//
//  Created by MJ Lee on 15/4/24.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "RCMJRefreshFooter.h"

@interface RCMJRefreshBackFooter : RCMJRefreshFooter

@end
