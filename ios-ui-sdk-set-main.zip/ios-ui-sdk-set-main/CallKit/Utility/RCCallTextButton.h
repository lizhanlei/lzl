//
//  RCArButton.h
//  RongCallKit
//
//  Created by Rong Cloud on 2021/1/11.
//  Copyright © 2021 Rong Cloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCCallTextButton : UIButton

@end
