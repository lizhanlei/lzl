//
//  RCCallUserCallInfoModel.m
//  RongCallKit
//
//  Created by RongCloud on 16/3/18.
//  Copyright © 2016年 RongCloud. All rights reserved.
//

#import "RCCallUserCallInfoModel.h"

@implementation RCCallUserCallInfoModel

@end
