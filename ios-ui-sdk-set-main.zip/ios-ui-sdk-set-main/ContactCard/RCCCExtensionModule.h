//
//  RCCCExtensionModule.h
//  RongContactCard
//
//  Created by Jue on 2017/1/11.
//  Copyright © 2017年 ios-rongContactCard. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RongContactCardAdaptiveHeader.h"
#import "RongContactCard.h"

@interface RCCCExtensionModule : NSObject <RongIMKitExtensionModule>

@end
