//
//  RCCCUserInfo.m
//  RongContactCard
//
//  Created by Jue on 2017/1/12.
//  Copyright © 2017年 ios-rongContactCard. All rights reserved.
//

#import "RCCCUserInfo.h"

@implementation RCCCUserInfo

@end
